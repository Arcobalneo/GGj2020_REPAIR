# README

**Game Name:Remain in a pair**

**Type:2D platform action**

**Unity version:2019.2.17f1**

**Runtime Env:Windows**

**operater instruction:**

press "->","<-" to control move direction

press "Space" to jump and confirm in menu

press "Esc" to back main menu anytime



**have fun!**




